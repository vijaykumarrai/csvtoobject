import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

public class Main {
	static Set<InputData> inputDatas;

	public static void main(String[] args) {
		inputDatas = readFromCSV("D:\\writtentest\\Sample_test\\src\\test.csv.txt");
		for (InputData data : inputDatas) {
			System.out.println(data.toString());
		}
		System.out.println(
				"Total number of teams in Acme working on offshore drilling : " + getTeams("Acme", "Offshoredrilling"));

		System.out.println("Dev team budget for project GERD is : " + getBudget("GERD", "Development"));
	}

	private static Set<InputData> readFromCSV(String fileName) {
		Set<InputData>inputDatas = new HashSet<>();
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)) {
			String line = br.readLine();
			while (line != null) {
				String[] attributes = line.split(",");
				InputData inputData = createInputData(attributes);
				inputDatas.add(inputData);
				line = br.readLine();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return inputDatas;
	}

	public static String getBudget(String projectCode, String team) {
		String budget = "";
		for (InputData data :inputDatas) {
			if (data.getProjectCode().equals(projectCode) && data.getTeam().equals(team)) {
				budget = data.getBudget();
			}
		}
		return budget;
	}

	public static int getTeams(String company, String project) {
		int teamCount = 0;
		for (InputData data :inputDatas) {
			if (data.getCompany().equals(company) && data.getProject().equals(project)) {
				teamCount++;
			}
		}
		return teamCount;
	}

	private static InputData createInputData(String[] metadata) {
		String company = metadata[0].replaceAll("^\"|\"$", "");
		String project = metadata[1].replaceAll("^\"|\"$", "");
		String projectCode = metadata[2].replaceAll("^\"|\"$", "");
		String budget = metadata[3].replaceAll("^\"|\"$", "");
		String team = metadata[4].replaceAll("^\"|\"$", "");
		return new InputData(company, project, projectCode, budget, team);
	}

}