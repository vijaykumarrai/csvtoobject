
public class InputData {
	public String company;
	public String project;
	public String projectCode;
	public String budget;
	public String team;

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public String getBudget() {
		return budget;
	}

	public void setBudget(String budget) {
		this.budget = budget;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public int hashCode() {
		return this.company.hashCode();
	}

	public InputData(String company, String project, String projectCode, String budget, String team) {
		super();
		this.company = company;
		this.project = project;
		this.projectCode = projectCode;
		this.budget = budget;
		this.team = team;
	}

	@Override
	public boolean equals(Object obj) {
		InputData k = (InputData) obj;
		
		if (this.company.equals(k.getCompany()) && this.projectCode.equals(k.getProjectCode())
				&& this.budget.equals(k.getBudget()) && this.team.equals(k.getTeam())) {
			return true;
		}
		return false;

	}

	public String toString() {
		return "[Company=" + company + " , project=" + project + " , budget=" + budget + " , team=" + team + "]";
	}
}
